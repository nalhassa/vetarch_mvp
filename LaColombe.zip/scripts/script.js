const TOAST_NOTIFICATION_TIMEOUT = 4 * 1000;

let smiElement, toastsContainer;

const mobileBannerURL = 'https://storage.googleapis.com/ordergroove-static-assets/la-colombe/La-Colombe-mobile-Give-10.png';
const desktopBannerURL = 'https://storage.googleapis.com/ordergroove-static-assets/la-colombe/La-Colombe-Desktop-Give-10.png';

const countriesPromise = fetch(
  'https://static.ordergroove.com/@ordergroove/i18n-data/latest/i18n_country_data.json'
).then(res => res.json());

async function render_countries_options(enabled_countries, localized_countries) {
  const html = ((window.og || {}).smi || {}).html;
  const countriesByCode = await countriesPromise;
  const enabledCountries = Object.entries(countriesByCode).filter(([code]) => enabled_countries.includes(code));
  const countriesHtml = enabledCountries
    .sort((a, b) => (a[1].name > b[1].name ? 1 : -1))
    .reduce((acc, [code, { name }]) => {
      const label = localized_countries[code] || name;
      acc.push(html`
        <option value="${code}">${label}</option>
      `);
      return acc;
    }, []);
  return countriesHtml;
}

function toggleStateSelect(stateSelectElement, show) {
  const stateSelectLabelElement = stateSelectElement.parentNode.querySelector('label');
  stateSelectElement.style.display = show ? 'block' : 'none';
  stateSelectElement.required = show;
  stateSelectLabelElement.style.display = show ? 'inline' : 'none';
}

async function handle_country_change(ev) {
  const countriesByCode = await countriesPromise;
  const selectedCountry = countriesByCode[ev.target.value];
  const states = selectedCountry ? selectedCountry.regions : null;
  const stateSelectElement = ev.target.closest('form').querySelector('[name="state_province_code"]');
  const selectLabel = stateSelectElement.querySelector('option').innerText;

  stateSelectElement.innerHTML = '';
  const nullOption = document.createElement('option');
  nullOption.value = '';
  nullOption.innerText = selectLabel;
  stateSelectElement.appendChild(nullOption);

  if (selectedCountry) {
    // Valid country selected
    if (states) {
      // Country has list of states/regions

      // Show state select field
      toggleStateSelect(stateSelectElement, true);

      // Append all states to select
      states.forEach(({ code, name }) => {
        const option = document.createElement('option');
        option.value = code;
        option.innerText = name;
        stateSelectElement.appendChild(option);
      });
    } else {
      // Country has no array of states/regions, e.g. France
      // Hide state select field
      toggleStateSelect(stateSelectElement, false);
    }
  } else {
    // Country un-selected
    // Show state select field
    toggleStateSelect(stateSelectElement, true);
  }
}

function html5_dialog_polyfill() {
  if (document.createElement('dialog').showModal) return;

  const script = document.createElement('script');
  script.src = 'https://cdnjs.cloudflare.com/ajax/libs/dialog-polyfill/0.5.6/dialog-polyfill.min.js';
  script.onload = () => {
    const dialogPolyfill = window.dialogPolyfill;
    smiElement.querySelectorAll('dialog').forEach(dialogPolyfill.registerDialog);

    const observer = new MutationObserver(mutationsList => {
      mutationsList.forEach(mutation => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach(addedNode => {
            if (addedNode.tagName === 'DIALOG') {
              dialogPolyfill.registerDialog(addedNode);
            } else if (addedNode.nodeType === 1) {
              const dialogs = addedNode.querySelectorAll('dialog');

              dialogs.forEach(dialog => dialogPolyfill.registerDialog(dialog));
            }
          });
        }
      });
    });
    observer.observe(smiElement, { subtree: true, childList: true });
  };
  document.head.appendChild(script);

  const ua = navigator.userAgent.toLowerCase();
  const isSafari = ua.includes('safari') && !(ua.includes('chrome') || ua.includes('chromium'));
  if (isSafari) {
    const link = document.createElement('link');
    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/dialog-polyfill/0.5.6/dialog-polyfill.min.css';

    document.head.appendChild(link);
  }
}

(function safari_request_submit_polyfill(prototype) {
  if (typeof prototype.requestSubmit === 'function') return;

  function raise(errorConstructor, message, name) {
    throw new errorConstructor(`Failed to execute 'requestSubmit' on 'HTMLFormElement': ${message}.`, name);
  }

  function validateSubmitter(submitter, form) {
    submitter instanceof HTMLElement || raise(TypeError, "parameter 1 is not of type 'HTMLElement'");
    submitter.type === 'submit' || raise(TypeError, 'The specified element is not a submit button');
    submitter.form === form ||
      raise(DOMException, 'The specified element is not owned by this form element', 'NotFoundError');
  }

  prototype.requestSubmit = function(submitter) {
    if (submitter) {
      validateSubmitter(submitter, this);
      submitter.click();
    } else {
      const sbm = document.createElement('input');
      sbm.type = 'submit';
      sbm.hidden = true;
      this.appendChild(sbm);
      sbm.click();
      this.removeChild(sbm);
    }
  };
})(HTMLFormElement.prototype);

function reset_state_options(element) {
  element.innerHTML = '';
  const option = document.createElement('option');
  option.value = '';
  option.innerText = 'Select a State/Province';
  element.appendChild(option);
  element.parentNode.querySelector('label').innerText = 'State/Province/Region ';
}

function show_and_append_modal(dialog) {
  dialog.showModal();
  dialog.appendChild(toastsContainer);
}

function show_closest_modal(ev) {
  const dialog = ev.target.parentNode.querySelector('dialog');
  show_and_append_modal(dialog);
}

function close_closest_modal(ev) {
  const dialog = ev.target.closest('dialog');
  dialog.close();
  smiElement.appendChild(toastsContainer);
}

function close_address_modal(ev) {
  close_closest_modal(ev);
  const $stateSelect = ev.target.querySelector('[name="state_province_code"]');
  reset_state_options($stateSelect);
}

function reset_cancel_divs(ev) {
  close_closest_modal(ev);
  const dialog = ev.target.closest('dialog');
  const divSkipOrder = dialog.querySelector('.og-cancel-subscription-skip');
  const divCancelReasons = dialog.querySelector('.og-cancel-subscription-select-reasons');
  divSkipOrder.hidden = false;
  divCancelReasons.hidden = true;
}

function show_cancel_reasons(ev) {
  const dialog = ev.target.closest('dialog');
  const divSkipOrder = dialog.querySelector('.og-cancel-subscription-skip');
  divSkipOrder.hidden = true;
  const divCancelReasons = dialog.querySelector('.og-cancel-subscription-select-reasons');
  divCancelReasons.hidden = false;
}

function reset_cancel_divs(ev) {
  close_closest_modal(ev);
  const dialog = ev.target.closest('dialog');
  const divSkipOrder = dialog.querySelector('.og-cancel-subscription-skip');
  const divCancelReasons = dialog.querySelector('.og-cancel-subscription-select-reasons');
  divSkipOrder.hidden = false;
  divCancelReasons.hidden = true;
}

function show_cancel_reasons(ev) {
  const dialog = ev.target.closest('dialog');
  const divSkipOrder = dialog.querySelector('.og-cancel-subscription-skip');
  divSkipOrder.hidden = true;
  const divCancelReasons = dialog.querySelector('.og-cancel-subscription-select-reasons');
  divCancelReasons.hidden = false;
}

async function do_skip_next_delivery(ev, order_id, order_item_id) {
  reset_cancel_divs(ev);
  if (window.og.smi.store.getState().items_by_order[order_id].length > 1) {
 await window.og.smi.api.request_delete_item(order_item_id);
  } else {
 await window.og.smi.api.request_skip_order(order_id);
  }
}


function toast_notification_animation() {
  function setupToasts() {
    const observer = new MutationObserver(mutationsList => {
      mutationsList.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType !== Node.ELEMENT_NODE) return;
          setTimeout(() => {
            node.classList.add('og-show');
          }, 1);
          setTimeout(() => {
            node.addEventListener('transitionend', () => {
              node.classList.add('og-hide');
            });
            node.classList.remove('og-show');
          }, TOAST_NOTIFICATION_TIMEOUT);
        });
      });
    });
    observer.observe(toastsContainer, { childList: true });
  }

  if (smiElement.querySelector('.og-toasts')) {
    toastsContainer = smiElement.querySelector('.og-toasts');
    setupToasts();
  } else {
    const observer = new MutationObserver(mutationsList => {
      mutationsList.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE && node.matches('.og-toasts')) {
            toastsContainer = node;
            setupToasts();
            observer.disconnect();
          }
        });
      });
    });
    observer.observe(smiElement, { subtree: true, childList: true });
  }
}

function disable_form_elements(ev) {
  ev.target.querySelectorAll('select,input,button').forEach(it => it.toggleAttribute('disabled', true));
}

function enable_form_elements(ev) {
  ev.target.querySelectorAll('select,input,button').forEach(it => it.toggleAttribute('disabled', false));
}

function submit_form_onchange(ev) {
  ev.target.closest('form').requestSubmit();
}

function nth_order_date(order, subscription, n = 1) {
  const increment = subscription.every * n;
  const unit = {
    '1': 'day',
    '2': 'week',
    '3': 'month'
  }[subscription.every_period];

  const dayjs = ((window.og || {}).smi || {}).dayjs;

  return typeof dayjs === 'function' ? dayjs(order.place).add(increment, unit) : null;
}

function bootstrap_flyout_menu() {
  const toggle = (el, force) => {
    const opened = force === undefined ? el.getAttribute('flyout-menu-toggle') === 'opened' : !force;
    el.setAttribute('flyout-menu-toggle', opened ? 'closed' : 'opened');
  };

  document.addEventListener('click', evt => {
    const toggler = evt.target.closest('[flyout-menu-toggle="opened"]');
    if (toggler && smiElement.contains(toggler)) return false;
    return smiElement.querySelectorAll('[flyout-menu-toggle]').forEach(el => toggle(el, false));
  });

  const register = function(el) {
    el.addEventListener('click', function(ev) {
      return el.contains(ev.target.closest('dialog')) ? false : toggle(el);
    });
  };

  const observer = new MutationObserver(mutationsList => {
    mutationsList
      .filter(mutation => mutation.type === 'childList')
      .forEach(mutation => {
        mutation.addedNodes.forEach(addedNode => {
          if (addedNode.nodeType === Node.ELEMENT_NODE) {
            if (addedNode.matches('[flyout-menu-toggle]')) {
              register(addedNode);
            } else {
              addedNode.querySelectorAll('[flyout-menu-toggle]').forEach(el => register(el));
            }
          }
        });
      });
  });
  observer.observe(smiElement, { subtree: true, childList: true });
}

function bootstrap(el) {
  smiElement = el;
  bootstrap_flyout_menu();
  html5_dialog_polyfill();
  toast_notification_animation();
}

if (document.querySelector('#og-msi,og-smi')) {
  bootstrap(document.querySelector('#og-msi,og-smi'));
} else {
  document.addEventListener('og:smi:ready', ev => {
    bootstrap(ev.target);
  });
}

function show_closest_tooltip(ev) {
  const tooltip = ev.currentTarget.parentNode.querySelector('.og-tooltip');
  tooltip.hidden = false;
}

function hide_closest_tooltip(ev) {
  const tooltip = ev.currentTarget.parentNode.querySelector('.og-tooltip');
  tooltip.hidden = true;
}

(function is_there_banner(){
  function check_for_banner(){
    if (document.querySelector('.og-hero-banner')){
      console.log('I found the banner');
      } else{
      make_the_banner();
    }
  }
  setTimeout(check_for_banner, 2000);

})();

function make_the_banner(){
  const getId = document.getElementById('og-insert-banner');
  const makeDiv = document.createElement('div');
  const mobileImg = '<a href="https://www.lacolombe.com/pages/refer?utm_source=subscriber_dashboard&utm_campaign=refer-a-friend"><img src="' + mobileBannerURL + '" class="og-hero-banner-mobile"></a>'
  const desktopImg = '<a href="https://www.lacolombe.com/pages/refer?utm_source=subscriber_dashboard&utm_campaign=refer-a-friend"><img src="' + desktopBannerURL + '" class="og-hero-banner-desktop"></a>'
  makeDiv.class = 'og-hero-banner';
  makeDiv.innerHTML = mobileImg + desktopImg;
  
  getId.appendChild(makeDiv)
}